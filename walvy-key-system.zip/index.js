
import express from "express";
import cors from "cors";
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import path from "path";
import { fileURLToPath } from "url";

// Konversi __dirname karena pakai ES Module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Inisialisasi server
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Inisialisasi LowDB
const adapter = new JSONFile("db.json");
const db = new Low(adapter, { keys: [] });

// Baca database
await db.read();

app.get("/keycheck.lua", async (req, res) => {
  const key = req.query.key;
  if (!key) return res.send('return warn("❌ Key tidak dimasukkan.")');

  await db.read();
  const found = db.data.keys.find(k => k.key === key);

  if (found) {
    res.send('return true -- ✅ Key valid dari server');
  } else {
    res.send('return warn("❌ Key tidak valid.")');
  }
});

// Endpoint GET untuk generate key
app.get("/api/key", async (req, res) => {
  let newKey;
  do {
    newKey = "WALVY-" + Math.random().toString(36).substring(2, 10).toUpperCase();
  } while (db.data.keys.includes(newKey));

  db.data.keys.push(newKey);
  await db.write();
  res.json({ key: newKey });
});

// Endpoint POST untuk validasi key
app.post("/api/key", async (req, res) => {
  const userKey = req.body.key;
  const isValid = db.data.keys.includes(userKey);
  res.json({ success: isValid });
});

// Menjalankan server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server aktif di http://0.0.0.0:${PORT}`);
});
